<?php
@include 'config.php';
session_start();
	if(isset($_POST["btnsignup"]) && $_POST["btnsignup"] != "")
	{
		$productname = $_POST["productname"];
		$phone = $_POST["expres"];
		$address = $_POST["address"];
		
		
		$con = new mysqli("localhost", "root", "", "cart_db") or die("error here");
		$query = "INSERT INTO `review`( `name`, `expression`, `feedback`) VALUES ('$productname', '$phone', '$address')";
		
		
		$result = mysqli_query($con, $query);
		if(isset($result) && $result != "")
		{
			$_SESSION['msg'] = 'Successfully order placed';
			header("location: index.html");
		}
		else
		{
			$_SESSION['msg'] = 'Sorry, some error.';
			header("location: account.html");
		}
	}
	else
	{
		$_SESSION['msg'] = 'You cannot access this page.';
		header("location: cart.html");
	}
?>

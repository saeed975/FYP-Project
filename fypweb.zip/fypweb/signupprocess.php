<?php
@include 'config.php';
session_start();
	if(isset($_POST["btnsignup"]) && $_POST["btnsignup"] != "")
	{
		$fullname = $_POST["txtfullname"];
		$email = $_POST["txtemail"];
		$password = $_POST["txtpassword"];
		
		
		$con = new mysqli("localhost", "root", "", "cart_db") or die("error here");
		$query = "INSERT INTO `user`( `username`, `email`, `password`) VALUES ('$fullname', '$email', '$password')";
		
		
		$result = mysqli_query($con, $query);
		if(isset($result) && $result != "")
		{
			$_SESSION['msg'] = 'Success, account created, Please Login';
			header("location: index.html");
		}
		else
		{
			$_SESSION['msg'] = 'Sorry, some error.';
			header("location: account.html");
		}
	}
	else
	{
		$_SESSION['msg'] = 'You cannot access this page.';
		header("location: cart.html");
	}
?>

<?php
@include 'config.php';
session_start();
	if(isset($_POST["btnsubmit"]) && $_POST["btnsubmit"] != "")
	{
		$uname = $_POST["txtemail"];
		$password = $_POST["txtpassword"];
		
		$con = new mysqli("localhost", "root", "", "cart_db") or die("error here");
		$query = "select * from admin where username = '$uname' and password = '$password'";
		$result = mysqli_query($con, $query);
		if(mysqli_num_rows($result) == 1)
		{
			$_SESSION["login_info"] = true;
			header("location: admin_page.php");
		}
		else
		{
			$_SESSION['msg'] = "Wrong username or password.";
			header("location: admin.php");
		}
	}
	else
	{
		$_SESSION['msg'] = 'You cannot access this page.';
		header("location: admin.php");
	}
?>
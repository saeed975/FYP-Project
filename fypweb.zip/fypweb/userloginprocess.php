<?php
session_start();
	if(isset($_POST["btnsubmit"]) && $_POST["btnsubmit"] != "")
	{
		$email = $_POST["txtemail"];
		$password = $_POST["txtpassword"];
		
		$con = new mysqli("localhost", "root", "", "cart_db") or die("error here");
		$query = "select * from user where email = '$email' and password = '$password'";
		$result = mysqli_query($con, $query);
		if(mysqli_num_rows($result) == 1)
		{
			$_SESSION["login_info"] = true;
			header("location: index.html");
		}
		else
		{
			$_SESSION['msg'] = "Wrong email or password.";
			header("location: aboutus.html");
		}
	}
	else
	{
		$_SESSION['msg'] = 'You cannot access this page.';
		header("location: cart.html");
	}
?>
<?php
	session_start();
	if(isset($_SESSION['msg']))
	{
		echo $_SESSION['msg'];
		unset($_SESSION['msg']);
	}
?>
<html>
<head>
	<title>Login Page</title>
    <link rel="stylesheet" href="./stylelogin.css">
</head>
<body>

<div id="bg"></div>

<form action="loginprocess.php" method="POST">
  <div class="form-field">
    <input type="text" placeholder="Username" name="txtemail" required/>
  </div>
  
  <div class="form-field">
    <input type="password" placeholder="Password" name="txtpassword" required/>                         </div>
  
  <div class="form-field">
    <button class="btn" type="submit" name="btnsubmit" value="Login">Log in</button>
  </div>
</form>

</body>
</html>

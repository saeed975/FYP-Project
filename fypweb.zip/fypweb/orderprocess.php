<?php
@include 'config.php';
session_start();
	if(isset($_POST["btnsignup"]) && $_POST["btnsignup"] != "")
	{
		$productname = $_POST["productname"];
		$productprice = $_POST["price"];
		$img = $_POST["img"];
        $Name = $_POST["name"];
		$phone = $_POST["phone"];
		$address = $_POST["address"];
		
		
		$con = new mysqli("localhost", "root", "", "cart_db") or die("error here");
		$query = "INSERT INTO `orders`( `name`, `image`, `price`,`UserName`, `phone`, `address`) VALUES ('$productname', '$img', '$productprice', '$Name', '$phone', '$address')";
		
		
		$result = mysqli_query($con, $query);
		if(isset($result) && $result != "")
		{
			$_SESSION['msg'] = 'Successfully order placed';
			header("location: index.html");
		}
		else
		{
			$_SESSION['msg'] = 'Sorry, some error.';
			header("location: account.html");
		}
	}
	else
	{
		$_SESSION['msg'] = 'You cannot access this page.';
		header("location: cart.html");
	}
?>
